# hl7.fhir.fr.medication#0.1.0: Guide d'implémentation du médicament

## Pages

* [Accueil](index.md)
* [La conciliation - Implémentation](conciliation-Implementation.md)
* [La dispensation - La dispensation nominative à délivrance reglobalisée](dispensation-DispensationNominativeDelivranceReglobalisee.md)
* [Artifacts Summary](artifacts.md)
* [Historique des travaux](suivitravaux.md)
* [La conciliation - Vue d'ensemble](conciliation-VueEnsemble.md)
* [Téléchargements et usages](downloads.md)
* [La dispensation - Discussion](dispensation-Discussion.md)
* [La conciliation - Introduction](conciliation-Intro.md)
* [La conciliation - Exemples](conciliation-Exemples.md)
* [La dispensation - La délivrance la plus simple](dispensation-DelivrancePlusSimple.md)
* [La dispensation - Introduction](dispensation-Intro.md)
* [La dispensation - Ressource MedicationDispense](dispensation-RessourceMedicationDispense.md)
* [La conciliation - Cas d'usage](conciliation-CasUsage.md)

## Resources

### CodeSystems

* [code system Interop'Santé - Type de document d'une ressource Composition du domaine Pharmacy](CodeSystem-fr-document-type.md)
* [code system Interop'Santé - Statut éditorial d'une valeur](CodeSystem-fr-editorial-status.md)
* [code system Interop'Santé - Nature des sources d'un Bilan Médicamenteux](CodeSystem-fr-medication-history-source-type.md)
* [code system Interop'Santé - divergence identifiée sur une ligne de traitement d'une FCT](CodeSystem-fr-medication-reconciliation-discrepancy.md)
* [code system Interop'Santé - Gravité de l'erreur sur une ligne de traitement d'une FCT](CodeSystem-fr-medication-reconciliation-outcome.md)
* [code system Interop'Santé - Résolution d'une divergence sur une ligne de traitement d'une FCT](CodeSystem-fr-medication-reconciliation-resolution.md)
* [code system Interop'Santé - Statut d'une ligne de traitement d'une FCT](CodeSystem-fr-medication-reconciliation-status.md)
* [code system Interop'Santé - Type d'écart/erreur sur une ligne de traitement d'une FCT](CodeSystem-fr-medication-reconciliation-type.md)
* [Medication_Ingredient_Strength_Codes](CodeSystem-medication-ingredient-strength-codes.md)

### ValueSets

* [French Method Of Administration](ValueSet-FrMethodOfAdministration.md)
* [value set Interop'Santé - type de document de la ressource Composition d'une FCT](ValueSet-fr-current-medication-document-type.md)
* [value set Interop'Santé - Statut éditorial d'une valeur](ValueSet-fr-editorial-status.md)
* [value set Interop'Santé - Codes identifiant les médicaments](ValueSet-fr-medication-code.md)
* [value set SIPh - Nature des sources d'un Bilan Médicamenteux](ValueSet-fr-medication-history-source-type.md)
* [value set Interop'Santé - type de document de la ressource Composition d'une FCT](ValueSet-fr-medication-reconciliation-document-type.md)
* [value set Interop'Santé - Gravité de l'erreur sur une ligne de traitement d'une FCT](ValueSet-fr-medication-reconciliation-outcome.md)
* [value set Interop'Santé - qualification de la divergence identifiée sur une ligne de traitement d'une FCT](ValueSet-fr-medication-reconciliation-qualified-discrepancy.md)
* [value set Interop'Santé - Résolution d'une divergence sur une ligne de traitement d'une FCT](ValueSet-fr-medication-reconciliation-resolution.md)
* [value set Interop'Santé - Statut d'une ligne de traitement d'une FCT](ValueSet-fr-medication-reconciliation-status.md)
* [value set Interop'Santé - Type d'écart/erreur sur une ligne de traitement d'une FCT](ValueSet-fr-medication-reconciliation-type.md)
* [French Medicinal product Dose form](ValueSet-fr-mp-dose-form.md)
* [French Route of Administration](ValueSet-fr-route-of-administration.md)
* [value set Interop'Santé - Codes identifiant les substances](ValueSet-fr-substance-code.md)
* [French overall intention of the treatment](ValueSet-fr-treatment-intent.md)
* [MedicationIngredientStrengthCodes](ValueSet-medication-ingredient-strength-codes.md)

### Complex-type Profiles

* [Range with UCUM or EDQM codes if code is used](StructureDefinition-FrRangeMedication.md)
* [Ratio with UCUM or EDQM codes if code is used](StructureDefinition-FrRatioMedication.md)
* [SimpleQuantity with UCUM or EDQM codes or code not used](StructureDefinition-FrSimpleQuantityMedication.md)
* [FR Meditinal Product Substance](StructureDefinition-fr-mp-substance.md)

### Resource Profiles

* [FR Current Medication Composition](StructureDefinition-fr-current-medication-composition.md)
* [FR Current Medication MedicationStatement](StructureDefinition-fr-current-medication-medicationstatement.md)
* [FR Inpatient MedicationDispense](StructureDefinition-fr-inpatient-medication-dispense.md)
* [FR Medication History Composition](StructureDefinition-fr-medication-history-composition.md)
* [FR Medication History MedicationStatement](StructureDefinition-fr-medication-history-medicationstatement.md)
* [FR Medication Reconciliation Composition](StructureDefinition-fr-medication-reconciliation-composition.md)
* [FR Medication Reconciliation MedicationStatement](StructureDefinition-fr-medication-reconciliation-statement.md)
* [FR Medication](StructureDefinition-fr-medication.md)
* [FR On Admission Medication Composition](StructureDefinition-fr-on-admission-medication-composition.md)
* [FR On Admission Retroactive Reconciliation Composition](StructureDefinition-fr-on-admission-retroactive-reconciliation-composition.md)

### Extensions

* [Medication descriptive properties](StructureDefinition-fr-drug-characteristic.md)
* [FRMedicationHistorySources](StructureDefinition-fr-medication-history-sources.md)
* [FRMedicationStatementReconciliationProperties](StructureDefinition-fr-medicationstatement-reconciliation-properties.md)
* [Strength CodeableConcept](StructureDefinition-fr-strength-codeableconcept.md)
* [MedicationRequest overall treatment intent](StructureDefinition-fr-treatment-intent.md)

### ImplementationGuides

* [Guide d'implémentation du médicament](index.md)

### Examples

* [InLine-patient-group-01 (Group)](Group-InLine-patient-group-01.md)
* [InLine-DOLIPRANE (Medication)](Medication-InLine-DOLIPRANE.md)
* [InLine-med-EFFERALGAN (Medication)](Medication-InLine-med-EFFERALGAN.md)
* [InLine-med-Paracetamol (Medication)](Medication-InLine-med-Paracetamol.md)
* [Disp-DOLIPRANE-Refill-Compl-presc-DC (MedicationDispense)](MedicationDispense-Disp-DOLIPRANE-Refill-Compl-presc-DC.md)
* [Disp-DOLIPRANE-Refill-Substit (MedicationDispense)](MedicationDispense-Disp-DOLIPRANE-Refill-Substit.md)
* [Disp-DOLIPRANE-Refill-presc-DC (MedicationDispense)](MedicationDispense-Disp-DOLIPRANE-Refill-presc-DC.md)
* [Disp-EFFERALGAN-presc-DC (MedicationDispense)](MedicationDispense-Disp-EFFERALGAN-presc-DC.md)
* [Disp-EFFERALGAN (MedicationDispense)](MedicationDispense-Disp-EFFERALGAN.md)
* [Disp-group01-1 (MedicationDispense)](MedicationDispense-Disp-group01-1.md)
* [Disp-group01-2 (MedicationDispense)](MedicationDispense-Disp-group01-2.md)
* [InLine-Presc-EFFERALGAN (MedicationRequest)](MedicationRequest-InLine-Presc-EFFERALGAN.md)
* [InLine-presc-EFFERALGAN2 (MedicationRequest)](MedicationRequest-InLine-presc-EFFERALGAN2.md)
* [InLine-presc-Paracetamol1 (MedicationRequest)](MedicationRequest-InLine-presc-Paracetamol1.md)
* [InLine-presc-Paracetamol2 (MedicationRequest)](MedicationRequest-InLine-presc-Paracetamol2.md)
* [InLine-Observation-poids-Avion (Observation)](Observation-InLine-Observation-poids-Avion.md)
* [InLine-observation-taille-Avion (Observation)](Observation-InLine-observation-taille-Avion.md)
* [InLine-patient-Avion (Patient)](Patient-InLine-patient-Avion.md)
* [InLine-practitioner-Luiggi (Practitioner)](Practitioner-InLine-practitioner-Luiggi.md)
