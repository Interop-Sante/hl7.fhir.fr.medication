# Accueil - Guide d'implémentation du médicament v0.1.0

* [**Table of Contents**](toc.md)
* **Accueil**

## Accueil

| | |
| :--- | :--- |
| *Official URL*:https://hl7.fr/ig/fhir/medication/ImplementationGuide/hl7.fhir.fr.medication | *Version*:0.1.0 |
| Draft as of 2026-05-27 | *Computable Name*:MED |

### Introduction

>  **Attention !** Cet Implementation Guide n'est pas la version courante. La version courante sera accessible via l'URL canonique (https://hl7.fr/ig/fhir/medication) lorsque celui-ci sera publié. 

Ce guide d’implémentation (IG) est une version historique en mode draft sur les deux cas d’usage:

1. [La dispensation](dispensation-Intro.md)
1. [La concilation](conciliation-Intro.md)

Ces domaines sont pris en charge par le GT Pharmacie d’HL7 France au sein de l’association [Interop’Santé](https://www.interopsante.org/) après une première version développée au sein de la communauté SIPh. L’historique des versions et des travaux est détaillé dans la page de [suivi des travaux](suivitravaux.md).

Cet IG a pour vocation à faire l’objet de travaux complémentaires d’alignement sur les profils européens et de traduction de flux PN13 en FHIR. Ces travaux déboucheront notamment sur deux IG à jour, un pour chaque domaine conciliation et dispensation.

#### Dépendances







#### Propriété intellectuelle

Certaines ressources sémantiques de ce guide sont protégées par des droits de propriété intellectuelle couverte par les déclarations ci-dessous. L’utilisation de ces ressources est soumise à l’acceptation et au respect des conditions précisées dans la licence d’utilisation de chacune d’entre elle.

* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.0.2/CodeSystem-ISO3166Part1.html): [FRCurrentMedicationComposition](StructureDefinition-fr-current-medication-composition.md), [FRCurrentMedicationMedicationStatement](StructureDefinition-fr-current-medication-medicationstatement.md)... Show 37 more, [FRInpatientMedicationDispense](StructureDefinition-fr-inpatient-medication-dispense.md), [FRMPSubstance](StructureDefinition-fr-mp-substance.md), [FRMedication](StructureDefinition-fr-medication.md), [FRMedicationCodes](ValueSet-fr-medication-code.md), [FRMedicationHistoryComposition](StructureDefinition-fr-medication-history-composition.md), [FRMedicationHistoryMedicationStatement](StructureDefinition-fr-medication-history-medicationstatement.md), [FRMedicationHistorySourceType](ValueSet-fr-medication-history-source-type.md), [FRMedicationHistorySources](StructureDefinition-fr-medication-history-sources.md), [FRMedicationReconciliationComposition](StructureDefinition-fr-medication-reconciliation-composition.md), [FRMedicationReconciliationDiscrepancy](CodeSystem-fr-medication-reconciliation-discrepancy.md), [FRMedicationReconciliationDocumentType](ValueSet-fr-medication-reconciliation-document-type.md), [FRMedicationReconciliationMedicationStatement](StructureDefinition-fr-medication-reconciliation-statement.md), [FRMedicationReconciliationOutcome](ValueSet-fr-medication-reconciliation-outcome.md), [FRMedicationReconciliationQualifiedDiscrepancy](ValueSet-fr-medication-reconciliation-qualified-discrepancy.md), [FRMedicationReconciliationResolution](ValueSet-fr-medication-reconciliation-resolution.md), [FRMedicationReconciliationStatus](ValueSet-fr-medication-reconciliation-status.md), [FRMedicationReconciliationType](ValueSet-fr-medication-reconciliation-type.md), [FRMedicationStatementReconciliationProperties](StructureDefinition-fr-medicationstatement-reconciliation-properties.md), [FROnAdmissionMedicationComposition](StructureDefinition-fr-on-admission-medication-composition.md), [FROnAdmissionRetroactiveReconciliationComposition](StructureDefinition-fr-on-admission-retroactive-reconciliation-composition.md), [FrCurrentMedicationDocumentType](ValueSet-fr-current-medication-document-type.md), [FrDocumentType](CodeSystem-fr-document-type.md), [FrDrugCharacteristic](StructureDefinition-fr-drug-characteristic.md), [FrEditorialStatus](ValueSet-fr-editorial-status.md), [FrMethodOfAdministration](ValueSet-FrMethodOfAdministration.md), [FrMpDoseForm](ValueSet-fr-mp-dose-form.md), [FrRangeMedication](StructureDefinition-FrRangeMedication.md), [FrRatioMedication](StructureDefinition-FrRatioMedication.md), [FrRouteOfAdministration](ValueSet-fr-route-of-administration.md), [FrSimpleQuantityMedication](StructureDefinition-FrSimpleQuantityMedication.md), [FrStrengthCodeableConcept](StructureDefinition-fr-strength-codeableconcept.md), [FrSubstanceCode](ValueSet-fr-substance-code.md), [FrTeatmentIntent](StructureDefinition-fr-treatment-intent.md), [FrTreatmentIntent](ValueSet-fr-treatment-intent.md), [MED](index.md), [MedicationIngredientStrengthCodes](ValueSet-medication-ingredient-strength-codes.md) and [Medication_Ingredient_Strength_Codes](CodeSystem-medication-ingredient-strength-codes.md)


* The UCUM codes, UCUM table (regardless of format), and UCUM Specification are copyright 1999-2009, Regenstrief Institute, Inc. and the Unified Codes for Units of Measures (UCUM) Organization. All rights reserved. [https://ucum.org/trac/wiki/TermsOfUse](https://ucum.org/trac/wiki/TermsOfUse)

* [Unified Code for Units of Measure (UCUM)](http://hl7.org/fhir/uv/xver-r5.r4/0.1.0/CodeSystem-v3-ucum.html): [Medication/InLine-DOLIPRANE](Medication-InLine-DOLIPRANE.md), [Medication/InLine-med-EFFERALGAN](Medication-InLine-med-EFFERALGAN.md)... Show 11 more, [MedicationDispense/Disp-DOLIPRANE-Refill-Compl-presc-DC](MedicationDispense-Disp-DOLIPRANE-Refill-Compl-presc-DC.md), [MedicationDispense/Disp-DOLIPRANE-Refill-Substit](MedicationDispense-Disp-DOLIPRANE-Refill-Substit.md), [MedicationDispense/Disp-DOLIPRANE-Refill-presc-DC](MedicationDispense-Disp-DOLIPRANE-Refill-presc-DC.md), [MedicationDispense/Disp-EFFERALGAN](MedicationDispense-Disp-EFFERALGAN.md), [MedicationDispense/Disp-EFFERALGAN-presc-DC](MedicationDispense-Disp-EFFERALGAN-presc-DC.md), [MedicationDispense/Disp-group01-1](MedicationDispense-Disp-group01-1.md), [MedicationDispense/Disp-group01-2](MedicationDispense-Disp-group01-2.md), [MedicationRequest/InLine-presc-Paracetamol1](MedicationRequest-InLine-presc-Paracetamol1.md), [MedicationRequest/InLine-presc-Paracetamol2](MedicationRequest-InLine-presc-Paracetamol2.md), [Observation/InLine-Observation-poids-Avion](Observation-InLine-Observation-poids-Avion.md) and [Observation/InLine-observation-taille-Avion](Observation-InLine-observation-taille-Avion.md)


* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* [LOINC](http://terminology.hl7.org/6.0.2/CodeSystem-v3-loinc.html): [FRMedicationHistoryComposition](StructureDefinition-fr-medication-history-composition.md), [FRMedicationReconciliationComposition](StructureDefinition-fr-medication-reconciliation-composition.md), [FROnAdmissionRetroactiveReconciliationComposition](StructureDefinition-fr-on-admission-retroactive-reconciliation-composition.md), [Observation/InLine-Observation-poids-Avion](Observation-InLine-Observation-poids-Avion.md) and [Observation/InLine-observation-taille-Avion](Observation-InLine-observation-taille-Avion.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [FrTeatmentIntent](StructureDefinition-fr-treatment-intent.md) and [FrTreatmentIntent](ValueSet-fr-treatment-intent.md)


* Unless otherwise indicated, reproduction of material posted on Council of Europe websites, and reproduction of photographs for which the Council of Europe holds copyright – see legal notice \“photo credits\” – is authorised for private use and for informational and educational uses relating to the Council of Europe’s work. This authorisation is subject to the condition that the source be indicated and no charge made for reproduction. Persons wishing to make some other use than those specified above, including commercial use, of information and text posted on these sites are asked to apply for prior written authorisation to the Council of Europe, Directorate of Communication.

* [EDQM Standard Terms](http://tx.fhir.org/r4/ValueSet/edqm): [FrMethodOfAdministration](ValueSet-FrMethodOfAdministration.md), [FrMpDoseForm](ValueSet-fr-mp-dose-form.md)... Show 12 more, [FrRouteOfAdministration](ValueSet-fr-route-of-administration.md), [Medication/InLine-DOLIPRANE](Medication-InLine-DOLIPRANE.md), [Medication/InLine-med-EFFERALGAN](Medication-InLine-med-EFFERALGAN.md), [MedicationDispense/Disp-DOLIPRANE-Refill-Compl-presc-DC](MedicationDispense-Disp-DOLIPRANE-Refill-Compl-presc-DC.md), [MedicationDispense/Disp-DOLIPRANE-Refill-Substit](MedicationDispense-Disp-DOLIPRANE-Refill-Substit.md), [MedicationDispense/Disp-DOLIPRANE-Refill-presc-DC](MedicationDispense-Disp-DOLIPRANE-Refill-presc-DC.md), [MedicationDispense/Disp-EFFERALGAN](MedicationDispense-Disp-EFFERALGAN.md), [MedicationDispense/Disp-EFFERALGAN-presc-DC](MedicationDispense-Disp-EFFERALGAN-presc-DC.md), [MedicationRequest/InLine-Presc-EFFERALGAN](MedicationRequest-InLine-Presc-EFFERALGAN.md), [MedicationRequest/InLine-presc-EFFERALGAN2](MedicationRequest-InLine-presc-EFFERALGAN2.md), [MedicationRequest/InLine-presc-Paracetamol1](MedicationRequest-InLine-presc-Paracetamol1.md) and [MedicationRequest/InLine-presc-Paracetamol2](MedicationRequest-InLine-presc-Paracetamol2.md)


