# TradPN13FHIR-Presc-perfusion-6-composants - Guide d'implémentation du médicament v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **TradPN13FHIR-Presc-perfusion-6-composants**

## Example Bundle: TradPN13FHIR-Presc-perfusion-6-composants



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "TradPN13FHIR-Presc-perfusion-6-composants",
  "meta" : {
    "profile" : [
      "https://hl7.fr/ig/fhir/medication/StructureDefinition/fr-prescription-bundle-for-example"
    ]
  },
  "type" : "searchset",
  "entry" : [
    {
      "resource" : {
        "resourceType" : "Patient",
        "id" : "patient-TradPN13FHIR-Presc-perfusion-6-composants",
        "meta" : {
          "profile" : [
            "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-patient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_patient-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><p class=\"res-header-id\"><b>Narratif généré : Patient patient-TradPN13FHIR-Presc-perfusion-6-composants</b></p><a name=\"patient-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><a name=\"hcpatient-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-patient.html\">FR Core Patient Profile</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">HENRY  Male, Date de Naissance :2000-01-01 ( Identifiant interne: 1234567891235000001820 (use: usual, ))</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Noms alternatifs (voir plus bas)\">Nom alternatif :</td><td colspan=\"3\">Jean (Official)</td></tr></table></div>"
        },
        "identifier" : [
          {
            "use" : "usual",
            "type" : {
              "coding" : [
                {
                  "system" : "https://hl7.fr/ig/fhir/core/CodeSystem/fr-core-cs-v2-0203",
                  "code" : "INTRN",
                  "display" : "Identifiant interne"
                }
              ]
            },
            "system" : "https://somehospital.fr/IPP",
            "value" : "1234567891235000001820"
          }
        ],
        "name" : [
          {
            "use" : "usual",
            "family" : "HENRY"
          },
          {
            "use" : "official",
            "given" : ["Jean"]
          }
        ],
        "gender" : "male",
        "birthDate" : "2000-01-01"
      }
    },
    {
      "resource" : {
        "resourceType" : "Practitioner",
        "id" : "practitioner-TradPN13FHIR-Presc-perfusion-6-composants",
        "meta" : {
          "profile" : [
            "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-practitioner"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_practitioner-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><p class=\"res-header-id\"><b>Narratif généré : Praticien practitioner-TradPN13FHIR-Presc-perfusion-6-composants</b></p><a name=\"practitioner-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><a name=\"hcpractitioner-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-practitioner.html\">FR Core Practitioner Profile</a></p></div><p><b>identifier</b>: Employee number/12345678910</p><p><b>name</b>: Charles DUPONT , Charles (Official)</p></div>"
        },
        "identifier" : [
          {
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "EI"
                }
              ]
            },
            "system" : "https://somehospital.fr/EI",
            "value" : "12345678910"
          }
        ],
        "name" : [
          {
            "use" : "usual",
            "family" : "DUPONT",
            "given" : ["Charles"]
          },
          {
            "use" : "official",
            "given" : ["Charles"]
          }
        ]
      }
    },
    {
      "resource" : {
        "resourceType" : "Medication",
        "id" : "medication-1-TradPN13FHIR-Presc-perfusion-6-composants",
        "meta" : {
          "profile" : [
            "https://hl7.fr/ig/fhir/medication/StructureDefinition/fr-medication-noncompound"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_medication-1-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><p class=\"res-header-id\"><b>Narratif généré : Médication medication-1-TradPN13FHIR-Presc-perfusion-6-composants</b></p><a name=\"medication-1-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><a name=\"hcmedication-1-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-medication-noncompound.html\">FR Medication Non Compound</a></p></div><p><b>code</b>: <span title=\"Codes :{http://data.esante.gouv.fr/ansm/medicament/UCD 3400894061175}\">NUTRYELT, sol à diluer pr perf, amp 10 mL</span></p><p><b>amount</b>: 1 Ampoule<span style=\"background: LightGoldenRodYellow\"> (Détails : code EDQM Standard Terms15002000 = 'Ampoule')</span>/1</p></div>"
        },
        "code" : {
          "coding" : [
            {
              "system" : "http://data.esante.gouv.fr/ansm/medicament/UCD",
              "code" : "3400894061175",
              "display" : "NUTRYELT PERF AMP10ML"
            }
          ],
          "text" : "NUTRYELT, sol à diluer pr perf, amp 10 mL"
        },
        "amount" : {
          "numerator" : {
            "value" : 1,
            "unit" : "Ampoule",
            "system" : "http://standardterms.edqm.eu",
            "code" : "15002000"
          },
          "denominator" : {
            "value" : 1
          }
        }
      }
    },
    {
      "resource" : {
        "resourceType" : "Medication",
        "id" : "medication-2-TradPN13FHIR-Presc-perfusion-6-composants",
        "meta" : {
          "profile" : [
            "https://hl7.fr/ig/fhir/medication/StructureDefinition/fr-medication-noncompound"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_medication-2-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><p class=\"res-header-id\"><b>Narratif généré : Médication medication-2-TradPN13FHIR-Presc-perfusion-6-composants</b></p><a name=\"medication-2-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><a name=\"hcmedication-2-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-medication-noncompound.html\">FR Medication Non Compound</a></p></div><p><b>code</b>: <span title=\"Codes :{http://data.esante.gouv.fr/ansm/medicament/UCD 3400892834719}\">POTASSIUM CHLORURE 1 g (10% Labo COOPER), sol à diluer pr perf, amp 10 mL</span></p><p><b>amount</b>: 1 Ampoule<span style=\"background: LightGoldenRodYellow\"> (Détails : code EDQM Standard Terms15002000 = 'Ampoule')</span>/1</p></div>"
        },
        "code" : {
          "coding" : [
            {
              "system" : "http://data.esante.gouv.fr/ansm/medicament/UCD",
              "code" : "3400892834719",
              "display" : "POTASSIUM 10% CPF AB10ML"
            }
          ],
          "text" : "POTASSIUM CHLORURE 1 g (10% Labo COOPER), sol à diluer pr perf, amp 10 mL"
        },
        "amount" : {
          "numerator" : {
            "value" : 1,
            "unit" : "Ampoule",
            "system" : "http://standardterms.edqm.eu",
            "code" : "15002000"
          },
          "denominator" : {
            "value" : 1
          }
        }
      }
    },
    {
      "resource" : {
        "resourceType" : "Medication",
        "id" : "medication-3-TradPN13FHIR-Presc-perfusion-6-composants",
        "meta" : {
          "profile" : [
            "https://hl7.fr/ig/fhir/medication/StructureDefinition/fr-medication-noncompound"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_medication-3-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><p class=\"res-header-id\"><b>Narratif généré : Médication medication-3-TradPN13FHIR-Presc-perfusion-6-composants</b></p><a name=\"medication-3-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><a name=\"hcmedication-3-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-medication-noncompound.html\">FR Medication Non Compound</a></p></div><p><b>code</b>: <span title=\"Codes :{http://data.esante.gouv.fr/ansm/medicament/UCD 3400892614236}\">MAGNESIUM CHLORURE 1 g (Labo LAVOISIER), sol inj, IV, amp 10 mL</span></p><p><b>amount</b>: 1 Ampoule<span style=\"background: LightGoldenRodYellow\"> (Détails : code EDQM Standard Terms15002000 = 'Ampoule')</span>/1</p></div>"
        },
        "code" : {
          "coding" : [
            {
              "system" : "http://data.esante.gouv.fr/ansm/medicament/UCD",
              "code" : "3400892614236",
              "display" : "MAGNESIUM C.10% LAV AB10ML"
            }
          ],
          "text" : "MAGNESIUM CHLORURE 1 g (Labo LAVOISIER), sol inj, IV, amp 10 mL"
        },
        "amount" : {
          "numerator" : {
            "value" : 1,
            "unit" : "Ampoule",
            "system" : "http://standardterms.edqm.eu",
            "code" : "15002000"
          },
          "denominator" : {
            "value" : 1
          }
        }
      }
    },
    {
      "resource" : {
        "resourceType" : "Medication",
        "id" : "medication-4-TradPN13FHIR-Presc-perfusion-6-composants",
        "meta" : {
          "profile" : [
            "https://hl7.fr/ig/fhir/medication/StructureDefinition/fr-medication-noncompound"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_medication-4-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><p class=\"res-header-id\"><b>Narratif généré : Médication medication-4-TradPN13FHIR-Presc-perfusion-6-composants</b></p><a name=\"medication-4-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><a name=\"hcmedication-4-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-medication-noncompound.html\">FR Medication Non Compound</a></p></div><p><b>code</b>: <span title=\"Codes :{http://data.esante.gouv.fr/ansm/medicament/UCD 3400893149416}\">LEVOFOLINATE DE CALCIUM 25 mg (Labo ZENTIVA), sol inj, IM IV, flac 2.5 mL</span></p><p><b>amount</b>: 1 Flacon<span style=\"background: LightGoldenRodYellow\"> (Détails : code EDQM Standard Terms15060000 = 'Vial')</span>/1</p></div>"
        },
        "code" : {
          "coding" : [
            {
              "system" : "http://data.esante.gouv.fr/ansm/medicament/UCD",
              "code" : "3400893149416",
              "display" : "CALCIUM LEV.ZEN 25MG/2,5ML FL"
            }
          ],
          "text" : "LEVOFOLINATE DE CALCIUM 25 mg (Labo ZENTIVA), sol inj, IM IV, flac 2.5 mL"
        },
        "amount" : {
          "numerator" : {
            "value" : 1,
            "unit" : "Flacon",
            "system" : "http://standardterms.edqm.eu",
            "code" : "15060000"
          },
          "denominator" : {
            "value" : 1
          }
        }
      }
    },
    {
      "resource" : {
        "resourceType" : "Medication",
        "id" : "medication-5-TradPN13FHIR-Presc-perfusion-6-composants",
        "meta" : {
          "profile" : [
            "https://hl7.fr/ig/fhir/medication/StructureDefinition/fr-medication-noncompound"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_medication-5-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><p class=\"res-header-id\"><b>Narratif généré : Médication medication-5-TradPN13FHIR-Presc-perfusion-6-composants</b></p><a name=\"medication-5-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><a name=\"hcmedication-5-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-medication-noncompound.html\">FR Medication Non Compound</a></p></div><p><b>code</b>: <span title=\"Codes :{http://data.esante.gouv.fr/ansm/medicament/UCD 3400891343281}\">CERNEVIT, pdr pr sol inj ou pr perf</span></p><p><b>amount</b>: 1 Flacon<span style=\"background: LightGoldenRodYellow\"> (Détails : code EDQM Standard Terms15060000 = 'Vial')</span>/1</p></div>"
        },
        "code" : {
          "coding" : [
            {
              "system" : "http://data.esante.gouv.fr/ansm/medicament/UCD",
              "code" : "3400891343281",
              "display" : "CERNEVIT INJ FL"
            }
          ],
          "text" : "CERNEVIT, pdr pr sol inj ou pr perf"
        },
        "amount" : {
          "numerator" : {
            "value" : 1,
            "unit" : "Flacon",
            "system" : "http://standardterms.edqm.eu",
            "code" : "15060000"
          },
          "denominator" : {
            "value" : 1
          }
        }
      }
    },
    {
      "resource" : {
        "resourceType" : "Medication",
        "id" : "medication-6-TradPN13FHIR-Presc-perfusion-6-composants",
        "meta" : {
          "profile" : [
            "https://hl7.fr/ig/fhir/medication/StructureDefinition/fr-medication-noncompound"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_medication-6-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><p class=\"res-header-id\"><b>Narratif généré : Médication medication-6-TradPN13FHIR-Presc-perfusion-6-composants</b></p><a name=\"medication-6-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><a name=\"hcmedication-6-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-medication-noncompound.html\">FR Medication Non Compound</a></p></div><p><b>code</b>: <span title=\"Codes :{http://data.esante.gouv.fr/ansm/medicament/UCD 3400891780475}\">SODIUM CHLORURE 0.9% (Labo B BRAUN), sol pr perf, poche 500 mL (ECOFLAC)</span></p><p><b>amount</b>: 1 Poche<span style=\"background: LightGoldenRodYellow\"> (Détails : code EDQM Standard Terms15005000 = 'Bag')</span>/1</p></div>"
        },
        "code" : {
          "coding" : [
            {
              "system" : "http://data.esante.gouv.fr/ansm/medicament/UCD",
              "code" : "3400891780475",
              "display" : "SODIUM 0,9% BBM INJ P.E500ML"
            }
          ],
          "text" : "SODIUM CHLORURE 0.9% (Labo B BRAUN), sol pr perf, poche 500 mL (ECOFLAC)"
        },
        "amount" : {
          "numerator" : {
            "value" : 1,
            "unit" : "Poche",
            "system" : "http://standardterms.edqm.eu",
            "code" : "15005000"
          },
          "denominator" : {
            "value" : 1
          }
        }
      }
    },
    {
      "resource" : {
        "resourceType" : "Medication",
        "id" : "medication-C-prescr-perf-6-exemple",
        "meta" : {
          "profile" : [
            "https://hl7.fr/ig/fhir/medication/StructureDefinition/fr-medication-compound"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_medication-C-prescr-perf-6-exemple\"> </a><p class=\"res-header-id\"><b>Narratif généré : Médication medication-C-prescr-perf-6-exemple</b></p><a name=\"medication-C-prescr-perf-6-exemple\"> </a><a name=\"hcmedication-C-prescr-perf-6-exemple\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-medication-compound.html\">FR Medication Compound</a></p></div><p><b>code</b>: <span title=\"Codes :\">NUTRYELT, sol à diluer pr perf, amp 10 mL + POTASSIUM CHLORURE 1 g (10% Labo COOPER), sol à diluer pr perf, amp 10 mL + MAGNESIUM CHLORURE 1 g (Labo LAVOISIER), sol inj, IV, amp 10 mL + LEVOFOLINATE DE CALCIUM 25 mg (Labo ZENTIVA), sol inj, IM IV, flac 2.5 mL + CERNEVIT, pdr pr sol inj ou pr perf + SODIUM CHLORURE 0.9% (Labo B BRAUN), sol pr perf, poche 500 mL (ECOFLAC)</span></p><blockquote><p><b>ingredient</b></p><p><b>item</b>: <code>#medication-1-TradPN13FHIR-Presc-perfusion-6-composants</code></p></blockquote><blockquote><p><b>ingredient</b></p><p><b>item</b>: <code>#medication-2-TradPN13FHIR-Presc-perfusion-6-composants</code></p></blockquote><blockquote><p><b>ingredient</b></p><p><b>item</b>: <code>#medication-3-TradPN13FHIR-Presc-perfusion-6-composants</code></p></blockquote><blockquote><p><b>ingredient</b></p><p><b>item</b>: <code>#medication-4-TradPN13FHIR-Presc-perfusion-6-composants</code></p></blockquote><blockquote><p><b>ingredient</b></p><p><b>item</b>: <code>#medication-5-TradPN13FHIR-Presc-perfusion-6-composants</code></p></blockquote><blockquote><p><b>ingredient</b></p><p><b>Medication component which is the vehicle of the compound Medication</b>: true</p><p><b>item</b>: <code>#medication-6-TradPN13FHIR-Presc-perfusion-6-composants</code></p></blockquote></div>"
        },
        "code" : {
          "text" : "NUTRYELT, sol à diluer pr perf, amp 10 mL + POTASSIUM CHLORURE 1 g (10% Labo COOPER), sol à diluer pr perf, amp 10 mL + MAGNESIUM CHLORURE 1 g (Labo LAVOISIER), sol inj, IV, amp 10 mL + LEVOFOLINATE DE CALCIUM 25 mg (Labo ZENTIVA), sol inj, IM IV, flac 2.5 mL + CERNEVIT, pdr pr sol inj ou pr perf + SODIUM CHLORURE 0.9% (Labo B BRAUN), sol pr perf, poche 500 mL (ECOFLAC)"
        },
        "ingredient" : [
          {
            "itemReference" : {
              "reference" : "#medication-1-TradPN13FHIR-Presc-perfusion-6-composants"
            }
          },
          {
            "itemReference" : {
              "reference" : "#medication-2-TradPN13FHIR-Presc-perfusion-6-composants"
            }
          },
          {
            "itemReference" : {
              "reference" : "#medication-3-TradPN13FHIR-Presc-perfusion-6-composants"
            }
          },
          {
            "itemReference" : {
              "reference" : "#medication-4-TradPN13FHIR-Presc-perfusion-6-composants"
            }
          },
          {
            "itemReference" : {
              "reference" : "#medication-5-TradPN13FHIR-Presc-perfusion-6-composants"
            }
          },
          {
            "extension" : [
              {
                "url" : "https://hl7.fr/ig/fhir/medication/StructureDefinition/fr-is-vehicle",
                "valueBoolean" : true
              }
            ],
            "itemReference" : {
              "reference" : "#medication-6-TradPN13FHIR-Presc-perfusion-6-composants"
            }
          }
        ]
      }
    },
    {
      "resource" : {
        "resourceType" : "Observation",
        "id" : "observation-1-TradPN13FHIR-Presc-perfusion-6-composants",
        "meta" : {
          "profile" : [
            "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-observation-body-height"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_observation-1-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><p class=\"res-header-id\"><b>Narratif généré : Observation observation-1-TradPN13FHIR-Presc-perfusion-6-composants</b></p><a name=\"observation-1-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><a name=\"hcobservation-1-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-observation-body-height.html\">FR Core Observation Body Height Profile</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes :{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital Signs</span></p><p><b>code</b>: <span title=\"Codes :{http://loinc.org 8302-2}\">Taille du patient [Longueur] Patient ; Numérique</span></p><p><b>subject</b>: <code>#patient-TradPN13FHIR-Presc-perfusion-6-composants</code></p><p><b>effective</b>: 2023-05-03 11:30:00+0200</p><p><b>value</b>: 181 cm<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMcm = 'cm')</span></p></div>"
        },
        "status" : "final",
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
                "code" : "vital-signs"
              }
            ]
          }
        ],
        "code" : {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "8302-2"
            }
          ]
        },
        "subject" : {
          "reference" : "#patient-TradPN13FHIR-Presc-perfusion-6-composants"
        },
        "effectiveDateTime" : "2023-05-03T11:30:00+02:00",
        "valueQuantity" : {
          "value" : 181,
          "unit" : "cm",
          "system" : "http://unitsofmeasure.org",
          "code" : "cm"
        }
      }
    },
    {
      "resource" : {
        "resourceType" : "Observation",
        "id" : "observation-2-TradPN13FHIR-Presc-perfusion-6-composants",
        "meta" : {
          "profile" : [
            "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-observation-body-weight"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_observation-2-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><p class=\"res-header-id\"><b>Narratif généré : Observation observation-2-TradPN13FHIR-Presc-perfusion-6-composants</b></p><a name=\"observation-2-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><a name=\"hcobservation-2-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-observation-body-weight.html\">FR Core Observation Body Weight Profile</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes :{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital Signs</span></p><p><b>code</b>: <span title=\"Codes :{http://loinc.org 29463-7}\">Poids corporel [Masse] Patient ; Numérique</span></p><p><b>subject</b>: <code>#patient-TradPN13FHIR-Presc-perfusion-6-composants</code></p><p><b>effective</b>: 2023-05-03 11:30:00+0200</p><p><b>value</b>: 79 kg<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMkg = 'kg')</span></p></div>"
        },
        "status" : "final",
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
                "code" : "vital-signs"
              }
            ]
          }
        ],
        "code" : {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "29463-7"
            }
          ]
        },
        "subject" : {
          "reference" : "#patient-TradPN13FHIR-Presc-perfusion-6-composants"
        },
        "effectiveDateTime" : "2023-05-03T11:30:00+02:00",
        "valueQuantity" : {
          "value" : 79,
          "unit" : "kg",
          "system" : "http://unitsofmeasure.org",
          "code" : "kg"
        }
      }
    },
    {
      "resource" : {
        "resourceType" : "Observation",
        "id" : "observation-3-TradPN13FHIR-Presc-perfusion-6-composants",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_observation-3-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><p class=\"res-header-id\"><b>Narratif généré : Observation observation-3-TradPN13FHIR-Presc-perfusion-6-composants</b></p><a name=\"observation-3-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><a name=\"hcobservation-3-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes :{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital Signs</span></p><p><b>code</b>: <span title=\"Codes :{http://loinc.org 33558-8}\">Créatinine clairance [Volume/Temps] Temps non précisé ; Urine+Sérum/Plasma ; Numérique</span></p><p><b>subject</b>: <code>#patient-TradPN13FHIR-Presc-perfusion-6-composants</code></p><p><b>effective</b>: 2023-05-03 11:30:00+0200</p><p><b>value</b>: 0 µmol/l<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMumol/L = 'umol/L')</span></p></div>"
        },
        "status" : "final",
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
                "code" : "vital-signs"
              }
            ]
          }
        ],
        "code" : {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "33558-8"
            }
          ]
        },
        "subject" : {
          "reference" : "#patient-TradPN13FHIR-Presc-perfusion-6-composants"
        },
        "effectiveDateTime" : "2023-05-03T11:30:00+02:00",
        "valueQuantity" : {
          "value" : 0,
          "unit" : "µmol/l",
          "system" : "http://unitsofmeasure.org",
          "code" : "umol/L"
        }
      }
    },
    {
      "resource" : {
        "resourceType" : "MedicationRequest",
        "id" : "medicationrequest-TradPN13FHIR-Presc-perfusion-6-composants",
        "meta" : {
          "profile" : [
            "https://hl7.fr/ig/fhir/medication/StructureDefinition/fr-inpatient-medicationrequest"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_medicationrequest-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><p class=\"res-header-id\"><b>Narratif généré : PrescriptionMédicamenteuseTODO medicationrequest-TradPN13FHIR-Presc-perfusion-6-composants</b></p><a name=\"medicationrequest-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><a name=\"hcmedicationrequest-TradPN13FHIR-Presc-perfusion-6-composants\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-inpatient-medicationrequest.html\">FR Inpatient MedicationRequest</a></p></div><p><b>identifier</b>: <code>https://somehospital.fr/PrescrptionLine-ID</code>/6166</p><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>priority</b>: Routine</p><p><b>medication</b>: <code>#medication-C-TradPN13FHIR-Presc-perfusion-6-composants</code></p><p><b>subject</b>: <code>#patient-TradPN13FHIR-Presc-perfusion-6-composants</code></p><p><b>encounter</b>: Identifier: <code>https://somehospital.fr/Sejour</code>/3</p><p><b>supportingInformation</b>: </p><ul><li><code>#observation-1-TradPN13FHIR-Presc-perfusion-6-composants</code></li><li><code>#observation-2-TradPN13FHIR-Presc-perfusion-6-composants</code></li><li><code>#observation-3-TradPN13FHIR-Presc-perfusion-6-composants</code></li></ul><p><b>authoredOn</b>: 2023-05-03 11:30:00+0200</p><p><b>requester</b>: <code>#practitioner-TradPN13FHIR-Presc-perfusion-6-composants</code></p><p><b>groupIdentifier</b>: <code>https://somehospital.fr/Prescrption-ID</code>/IdentifiantAttribuéPourLaTraductionEnFHIR</p><p><b>note</b>: </p><blockquote><div><p><strong>Prescription textuelle:</strong> 1 préparation en continu sur 12h00 par jour</p>\n</div></blockquote><blockquote><p><b>dosageInstruction</b></p><p><b>timing</b>: Durée 720hours , Une fois par 12 hours</p><p><b>route</b>: <span title=\"Codes :{http://standardterms.edqm.eu 20045000}\">Voie intraveineuse</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>1 Poche<span style=\"background: LightGoldenRodYellow\"> (Détails : code EDQM Standard Terms15005000 = 'Bag')</span></td></tr></table></blockquote></div>"
        },
        "identifier" : [
          {
            "system" : "https://somehospital.fr/PrescrptionLine-ID",
            "value" : "6166"
          }
        ],
        "status" : "active",
        "intent" : "order",
        "priority" : "routine",
        "medicationReference" : {
          "reference" : "#medication-C-TradPN13FHIR-Presc-perfusion-6-composants"
        },
        "subject" : {
          "reference" : "#patient-TradPN13FHIR-Presc-perfusion-6-composants"
        },
        "encounter" : {
          "identifier" : {
            "system" : "https://somehospital.fr/Sejour",
            "value" : "3"
          }
        },
        "supportingInformation" : [
          {
            "reference" : "#observation-1-TradPN13FHIR-Presc-perfusion-6-composants"
          },
          {
            "reference" : "#observation-2-TradPN13FHIR-Presc-perfusion-6-composants"
          },
          {
            "reference" : "#observation-3-TradPN13FHIR-Presc-perfusion-6-composants"
          }
        ],
        "authoredOn" : "2023-05-03T11:30:00+02:00",
        "requester" : {
          "reference" : "#practitioner-TradPN13FHIR-Presc-perfusion-6-composants"
        },
        "groupIdentifier" : {
          "system" : "https://somehospital.fr/Prescrption-ID",
          "value" : "IdentifiantAttribuéPourLaTraductionEnFHIR"
        },
        "note" : [
          {
            "extension" : [
              {
                "url" : "https://hl7.fr/ig/fhir/medication/StructureDefinition/fr-medicationrequest-note-scope",
                "valueCode" : "LIPRESCTXT"
              }
            ],
            "text" : "**Prescription textuelle:** 1 préparation en continu sur 12h00 par jour"
          }
        ],
        "dosageInstruction" : [
          {
            "timing" : {
              "repeat" : {
                "boundsPeriod" : {
                  "start" : "2023-05-03T10:00:00+02:00"
                },
                "duration" : 720,
                "durationUnit" : "min",
                "frequency" : 1,
                "period" : 12,
                "periodUnit" : "h",
                "timeOfDay" : ["10:00:00"]
              }
            },
            "route" : {
              "coding" : [
                {
                  "system" : "http://standardterms.edqm.eu",
                  "code" : "20045000",
                  "display" : "Voie intraveineuse"
                }
              ]
            },
            "doseAndRate" : [
              {
                "doseQuantity" : {
                  "value" : 1,
                  "unit" : "Poche",
                  "system" : "http://standardterms.edqm.eu",
                  "code" : "15005000"
                }
              }
            ]
          }
        ]
      }
    }
  ]
}

```
