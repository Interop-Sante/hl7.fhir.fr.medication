# La conciliation - Cas d'usage - Guide d'implémentation du médicament v0.1.0

* [**Table of Contents**](toc.md)
* **La conciliation - Cas d'usage**

## La conciliation - Cas d'usage

> **Attention !**la partie conciliation est en draft et n'a pas été éprouvé, un groupe de travail dédié doit être lancé afin de faire évoluer le besoin.

### Cas d’usage

Aucun cas d’usage Le cas d’usage qui a servi de fil conducteur n’est pas (encore) finalisé dans ce guide. C’est un non-choix par défaut de temps disponible …

