# La conciliation - Exemples - Guide d'implémentation du médicament v0.1.0

* [**Table of Contents**](toc.md)
* **La conciliation - Exemples**

## La conciliation - Exemples

> **Attention !**la partie conciliation est en draft et n'a pas été éprouvé, un groupe de travail dédié doit être lancé afin de faire évoluer le besoin.

### Exemples

Aucun exemple

* Les exemples de ressources tirés du cas d’usage conducteur ne sont pas (encore) publiés dans ce guide.
* C’est un non-choix par défaut de temps disponible pour les finaliser …

